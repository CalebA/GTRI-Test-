DevOps Support
==============

This position will require a significant amount of collaboration with developers
and testers. You will be expected to support the development process.
Experience with ITIL or Continuous Delivery environments is preferred.

Question
========

Please explain the extent of your experience in DevOps environments. Include
information about specific software development methodologies you have
supported and your specific role in these environments. 

I have worked in a DevOps environment as an integration engineer at Cox Communications. We had an mobile application called Cox TV Connect (CTVC) which enabled customers to watch linear video on iPads, iPhones, Android, and PC/MAC clients. There were three parts to the test enviroment which were testers, verifiers, developers. The testers would strictly only do testing and verifying, but not troubleshooting. The verifiers would would validated QA defects and troubleshoot any enviromental issues. The developers would only resolve code based issues and create MOPs for production. Verifiers would also execute the MOPs before handing off to the production OPs. My role in this environment was to be the liasion between the testers, verifiers, and developers. I would manage the defects to verify that they were really issues and resolve any non-code related issues. I would also gather and create documents to give to OPs used to help troubleshoot any issues. 
