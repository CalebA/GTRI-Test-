Hardware Requisition, Provisioning and Trouble-Shooting
=======================================================

Answer the following questions.

Q1) What is the difference between a RAID adapter and an HBA?

RAID is short for Redundent Array of independent disks which is a storage technology that combines multiple disk drive components into a logical unit. Data is distributed across the drives in several ways depending on the level of redundancy and performance required. HBA or host bus adapter connects to a host system to other network and storage devices (this includes SCSI, Fibre Channels and eSATA devices). 

The main difference of these two devices is that an HBA is a general connectivity device that when it does offer RAID support, it utilizes a system's CPU for processing. A RAID controller offers three primary benefits which are it offloads RAID functionality to an I/O processor, it is OS independent, and is more feature-rich. HBA are less complex, so are usually cheaper than RAID. 
-------------------------------------------------------------

Q2) Switch, Hub, Router. Compare and Contrast.

Switches are devices capable of creating temporary connections between two or more devices linked to the switch. Some nodes of a switch can be connected end to end, while others may only be used for routing. A hub is a central device in a star network that provides a common connection among nodes. A router is an internetowrking device that is attached to two or more networks and forwards packets from one network to another. Routers, switches, and hubs all share the same physical characteristics and support full duplex transport mode. 

A router is a more sophisticated network device when compared to either a hub or a switch. Routers typically join multiple LANs and WANs together and servers as an intermediate destination for network traffic. Switches are higher-performance alternative to hubs and are typically used in homes when the user has four or more computers. Hubs operate on a brocast model while switches operate using a virtual circuit model. Hubs are typically the most simplistic of the three and simply pass all network traffic to each node. Switches are capable of determining the destination of each traffic element and selectively forwards data to the one computer it actually needs. Switches perform much better on busy networks.  

----------------------------------------------

Q3) What matters when deciding between hardware and virtualized machines?

When deciding between using between hardware and virtual machine one would need to decide how often the operating system will be used. For instance, an OS that requires less maintance should be used on a virtual machine to avoid constant reboots. Virtual Machines sometimes may be limited by performace and storage depending on the resources that the host computer allocated to it. Video streaming on virtual machines is usually degraded. Hardware Machines should be used for highly used servers, while Virtual Machines should be used for low maintainance servers. 

-------------------------------------------------------------------------

Q4) On a $6000 budget, spec out a stand-alone storage server.

Dell PowerEdge R720
 
SYSTEM OPTIONS
Chassis Configuration
	2.5" Chassis with up to 8 Hard Drives	
Processor
	Intel® Xeon® E5-2640 2.50GHz, 15M Cache, 7.2GT/s QPI, Turbo, 6C, 95W, Max Mem 1333MHz	
Additional Processor
	Intel® Xeon® E5-2640 2.50GHz, 15M Cache, 7.2GT/s QPI, Turbo, 6C, 95W	
Memory Configuration Type
	Memory Mirroring	
Memory DIMM Type and Speed
	1333 MHz LRDIMMs	
Memory Capacity
	32GB LRDIMM, 1333 MT/s, Low Volt, Quad Rank, x4 Data Width	
Operating System
	Red Hat Enterprise Linux 6.3,Factory Install,x64,Req Lic&Sub Selection	
OS Media Kits
	Red Hat Enterprise Linux 6.3,Media Only X86_64,No Subscription,Factory Instal	
OS Media Kits
	Red Hat Enterprise Linux 5.8,Media Only X86_64,No Subscription,Drop in Box
RAID Configuration
	RAID 0 for H710P/H710/H310 (1-16 HDDs)	
RAID Controller
	Embedded SATA
Hard Drives
	200GB Solid State Drive SATA Value MLC 3Gbps 2.5in Hot-plug Drive-Limited Warranty
Embedded Systems Management
	iDRAC7 Express	
Select Network Adapter
	Intel X520 DP 10Gb DA/SFP+, + I350 DP 1Gb Ethernet, Network Daughter Card	
PCIe Riser
	Risers with up to 6, x8 PCIe Slots + 1, x16 PCIe Slot	
Power Supply
	Single, Hot-plug Power Supply (1+0), 495W	
Power Cords
	NEMA 5-15P to C13 Wall Plug, 125 Volt, 15 AMP, 10 Feet (3m), Power Cord	
Power Management BIOS Settings
	Power Saving Dell Active Power Controller	
Rack Rails
	No Rack Rails or Cable Management Arm	
Bezel
	No Bezel	
Internal Optical Drive
	No Internal Optical Drive	
System Documentation
	Electronic System Documentation and OpenManage DVD Kit for R720	
Virtualization Software
	VMware ESXi v4.1 U2	
Internal SD Module
	Internal SD Module with 2GB SD Card
Server Accessories
	8x DVD-ROM, USB, External	
Advanced Data Protection Software
	None	
Additional Software
	None	
Warranty & Service
	3 Year ProSupport and NBD On-site Service	

Total Price $5,876.79

The Dell PowerEdge R720 was chosen for the simple fact that for the price the user gets more standard features and equipment than the comparable HP DL380 G7. The Dell Poweredge allows for better memory and HDD expansion (up to 768GB and 32TB respectively).
-------------------------------------------------------------

Q5) How would you provision the previous machine for production?

The machine created above will have RHEL 6.3 and VMware ESXI factory install. RHEL will be the primary operating system with VMware running Windows Server 2012 if needed in the environment.  

----------------------------------------------------------------

Q6) Scenario 1:
---------------
Write through-put on your storage server is falling. How would you diagnose the issues?

Both Windows and Linux typically prompt the user that the server disk drive is almost full. To diagnose this in Windows the user will have to go into "My Computer" access the primary drive and do a disk clean-up to free up space. In Linux the user should open the terminal and use the df -h command to determine which filesystem is running out of space. Next, the user should type du -h /var/log to check the sizes of all of the log file. If it is a log file causing the issue make sure it is cleaned out. The user can then create a script to clean the log file every day or every few days.  The user can also run a yum clean all to clean up old deleted programs. 

Q7) Scenario 2:
---------------
The storage volume is filling up. You have four calendar weeks and $3000. Requisition and provision new hardware. Downtime on the storage must be kept below 5 minutes. Don't let the storage volume hit the cap.

Week 1: Order and provison new hard drive to move all of the data
Week 2 and 3: Perform QA work on a similar test server to determine the most effective ways to install new hard drive or move data. During this time create a script to start appending new data to hard drive. 
Week 4: Try to install and move data to new drive from QA testing done in weeks 2 and 3. The administrator can the point all directories to the new drive. 

