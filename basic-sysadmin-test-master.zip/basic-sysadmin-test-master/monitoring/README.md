Production Monitoring
=====================

Q1) A service is repeatedly crashing. How do you identify possible causes?

The quickest way to determine why a service is repeatedly crash is by checking the logs to see when and possibly what is triggering the service to stop. In Windows, the administrator could look at the exe associated with the service and in Linux, the configuration file can be checked. In some causes the configuration file on the server may be incorrect which is causes the service to crash. 
--------------------------------------------------------------------------

Q2) Scenario:
-------------
Given a collection of internal assets which are partitioned into several classes where each class runs a distinct set of services. Network structure is such that two nodes of different classes may not be able to directly communicate. One class of nodes is for data aggregation and another integrates to an external enterprise peer. There is a message bus for passing work between classes.

Describe in bullet points how you would monitor such a system. Include a set of health metrics and targets.

-Monitor the status of each  service
-Put a network sniffer (such as snort)to monitor each node since the servers are on two different classes of nodes 
 
Q3) In Linux, how do you identify what resources a given process has?

The top command will be the easiest way to determine what resource a each running process has. 
---------------------------------------------------------------------

