External Connectivity
=====================
Our production assets require high-availability to external resources as the
information gathered is time-sensitive and missed results may not be
recoverable.

Q1) Heart-beat Check
====================
Include in this directory a script which verifies that a given IP address is
not blacklisted from any public IRC service.

Blacklists can be done in Apache. The configuration file is found in the following directory /etc/httpd/conf/httpd.conf. 

The administrator can add the following lines the end of the script to block external IPs or IRC services. 

Proxy *>
Order deny,allow
Deny from all
Allow from internal.example.com
</Proxy> 

Q2) Feedback
============
Describe how you would ensure timely feedback in the event that an asset in
production is blacklisted.

In a production environment, a maintainance window should be created to blacklist or make any changes in a production environment. This will ensure that the customers will not be affected and that OPs has enough time to fix the issue. 

Q3) Enterprise Integration
==========================
How would you ensure connectivity between an order-processing asset and an
external credit card processing system? If you have never worked with such
a system, describe another enterprise integration issue from your experience.

I have worked with Application servers that need to be integrated into an active test environment. One of the biggest issues that I faced was ensuring connectivity between the new server added and the current servers. I had a hard time allocating the correct IP address to the server and adding those ports to the correct VLAN to talk with other server. After troubleshooting the ports on the VLAN and the server the issue was resolved. 

