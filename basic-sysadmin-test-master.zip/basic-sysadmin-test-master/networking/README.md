Networking Architecture, Design and Maintainence
================================================

Please answer the following questions.

Q1) What are the OSI layers and how do they relate day-to-day operations?

Physical Layer- Transmission medium such as Cable, Fiber, or Wifi (Electric Signals)
Data Link Layer- This is the Layer that NICS are on/ used for Error Checking
Network Layer- Determines the best route for data (routers, switches, hubs)
Transport Layer- Packets are delivered reliably (received in proper order)
Session Layer- Conversation between two computers (starting, ending, and maintaining conversations)
Presentation Layer- Operating Systems, converts text and numbers that a user can understand into what computers can understand. 
Application Layer- Software applications such Chrome or Firefox. 

-------------------------------------------------------------------------

Q2) Cisco/Juniper/Equivalent: Pick one and explain how to configure a VLAN.

Below are the steps to configure VLAN on on a Cisco 2950 Switch.

1. Determine which VLAN interface will be used.
2. Name the VLAN with a specific name to easily identify the port. 
3. Determine which port will ne put on the VLAN (This will enable port to communicate with one another).
4. To allow ports on one VLAN to communicate with ports on another VLAN, a trunck port on the router will need to be configured. This will strip off the VLAN information, route the packet, and add back the VLAN information.

Configuring a VLAN will look like this
#vlan 6
#name marketing
#exit
#interface fast 
#interface fastEthernet 0/2
#switchport mode access
#switchport access vlan 6
#exit  
---------------------------------------------------------------------------

Q3) What is the difference between an application switch and a layer-2/3 switch?

An application switch is a suite of technologies that when deployed together, provide application availability, security, visibility, and acceleration. At the controller, an advanced traffic management device known as a web switch, content switch, or multilayer switch, has a main purpose of distributing traffic among a number of servers or geographically dislocated sites based on application specific criteria. These switches evolved from layer 4-7 switches, where load balancing techniques were not robust enough to handle the increasing complex mix of application traffic being delivered over a wide variety of network connectivity. Application switches usually work with layer 4 and 7 of the OSI model. 

Layer 2/3 switces are is a connection oriented connection service that is delivered by means of packet mode communication. After the virtual circuit is established between the two nodes or application processes a stream may be delivered between the nodes. Layer 2/3 switches work with layer 2 and 3 of the OSI model. Using these layers means that data is always delivered along the same network path.  
--------------------------------------------------------------------------------

Q4) How does virtualization interact with network design?

Virtualization works with network design to give access to more resources on a network. For instance, virtual machines can be configured with one or more virtual ethernet adapters, each of which has it's own IP and MAC address. As a reult, the virtual networks will have the same properties as a physcial network. The same can be said about a virtual switch. 
---------------------------------------------------------

Q5) TCP Handshake. What is it?

TCP handshake is a three way handshake used in the TCP protocol. It is often referred to as SYN, SYN-ACK, ACK, since there are three messages transmitted by TCP to negotiate and start a TCP session between two computers. 

Host 1 sends a TCP SYNchronize packet to Host 2
Host 2 recieves the A's synchronize packet
Host 2 send a SYNchronize-ACKnowledgement
Host 1 receives Host's 2 SYNchronize-ACKnowledgement
Host 1 sends ACKnowledgement
Host 2 recieves ACKnoledgement
The TCP socket connect is established 
------------------------------

Q6) What is the difference between a MAC address and an IP address?

MAC address or Media Access Control address is a unique identifier assigned to network interfaces for communication on the physical network segment. MAC addresses are often assigned ny the manufacturer of a NIC and stored in its hardware. Also referred to as burned in address or Ethernet hardware address. An IP address is a numerical label assigned to each device in a computer network that uses the Internet Protocol for communications. IP addresses serve as hosts or network interface identifiers and location addressing. For IPV4, an IP address is a 32 bit number. 

-------------------------------------------------------------------

Q7) ARP Storm vs ARP Poisoning. Compare and Contrast.

An ARP Storm is excessive traffic on a network that would cause the network to shutdown. This can also be called MAC flooding, which in this scenario a switch is fed many Ethernet frames, each containing different source MAC addresses, by the attacker. The intention is to consume the limited amount of memory set aside in the switch to store MAC addresses. ARP Poisioning or ARP spoofing is a technique whereby an attacker sends fake ARP messages onto a Local Area Network. Generally the aim is to associate the attacker's MAC address with the IP address of another host causing traffic to be sent to the attacker instead. The attacker can intercept data frames on a LAN, modify traffic, or stop traffic completely. 

These two attacks are similar for the simple fact that an attacker is using ARP to either flood the MAC or intercept data frames. Both can be resolved by restarting the network. These two attacks differ by the methods that the attacker uses. ARP Storms attack the MAC address by overloading the MAC table of a switch, while ARP Poisoning attacks the MAC address with the IP address. 
-----------------------------------------------------

Q8) Scenario Response:
----------------------
Your organization's network administrator contacts you, noting that a host using IP 192.168.100.106 is flooding the network.  You decide to take that host offline in the short term to prevent additional flooding.  Your network uses Cisco switches.  How would you identify which port to shut down?

To resolve TCP SYN Flooding issues such as this one on a Cisco switch the user can do the following configuration:

Switch# configure terminal
Switch(config)# psp dchp pps 35

This will configure protocol storm to drop incoming DHCP when it exceeds 35 packets per second. From that, the user can see which port is rejecting DHCP requests and shutdown the port. 



