Scripting and Automation
========================

Q1) Bash-Fu, Python Prowess, Perl Perfection, Ruby Revelation...
----------------------------------------------------------------
Drop a script in this directory which does something amazing.

/bin/bash (I'm not actually sure what is being asked)

Q2) Explain
-----------
What are the interesting parts of your script? What do they do?

I was given a project to append user data gathered from testers into a database to observe changes in user data. To accomplish this issue a Linux, Apache,  MySQL, PHP (LAMP) server was created for hosting field trial data. PHP scripts were created to append and parse user data into a MySQL database. After the data was sent to the database, a MySQL query was created to display (in tables) the collected data on webpages using HTML and PHP. These tables could be exported into an Excel spreadsheet. Jgraph, a PHP extension, was used to create a graphical representation of the data trends.

Q3) Automated Provisioning
--------------------------
Puppet, Chef, Salt, Fabric, vCenter. What are they? Tell me why I should care
about them. Describe your experiences with some or all of them.

Puppet is an open source configuration management tool written in Ruby. Puppet is a tool designed to manage the configuration of Unix-like and Windows systems. It retrives the client confiuration from the "puppet master" and applies it to the local host. 

Chef is a configuration management tool written in Ruby, used for writing system configuration "recipes" or "cookbooks". Chef will automatically set-up and tweak operating systems and programs.

Salt is an open source configuration management and remote execution application. Salt allows for commands to be executed across multiple remote servers in parallel. 

Fabric is a command-line tool used for streamlining the use of SSH for application development or system administration tasks. It provides a basic suite of operations for executing local and remote shell commands or uploading and downloading files.

vCenter (formerly known as VirtualCenter) is a centralized management tool for Vsphere suite. It was developed by VMware and it allows management of multiple ESX servers and virtual machines. 

The benefit of using all of these programs is to create a way to easily manage multiple server using scripting. Using these programs could help minimize time and resources used when configuring servers. 

Unfortunately, I have never worked with any of these software. 

