Security
========

Q1) What is SSL?

SSL stands for Secure Sockets Layer which is a cryptographic protocol developed by Netscape whish is used from managing the security of a message transmission on the internet. 

----------------

Q2) What is the sudoers file? What is its purpose?

The sudoers configuration file determines a user's sudo privileges. It is the default sudo policy plugin and is driven by the /etc/sudoers file. The purpose of this file is to allow users to run programs with the security privileges of another user such as root. The sudoers file is able to enable different configurations such as enabling root commands, control of users and groups, and not requiring passwords when invoking certain commands.  

--------------------------------------------------

Q3) Compare and contrast password, key and certificate authentication.

A password is a string of characters used to connect a user to a specific device or application. A key is a number (or set of numbers) that the cipher (encryption and decryption algorithms) operate on. Certificate Authorization is an authentication method that provides security for TCP/IP connections. Passwords, keys and certificate authentication are all used for authenication and authorization for different applications. 

Passwords are usually very basic and are only used to encrypt files. Passwords are typically only used when answering a programs request. Keys differ from passwords since they are usually bit strings of different lengths used to encrypt or decrpyt data. Keys differ from certificates for the simple fact that keys are stand alone credentials, while certificates must be verified. Certificates typically use SSL as their form of encryption.  

----------------------------------------------------------------------

Q4) How do you enable certificate authentication in Apache?

The simplest way to enable certificate authentication in Apache is to access the http.conf file and add the following lines to the file:  

httpd.conf

SSLVerifyClient      none
<Directory /usr/local/apache2/htdocs/secure/area>

SSLVerifyClient      require
SSLVerifyDepth       5
SSLCACertificateFile conf/ssl.crt/ca.crt
SSLCACertificatePath conf/ssl.crt
SSLOptions           +FakeBasicAuth
SSLRequireSSL
AuthName             "Snake Oil Authentication"
AuthType             Basic
AuthUserFile         /usr/local/apache2/conf/httpd.passwd
require              valid-user
</Directory>
-----------------------------------------------------------

Q5) How do you handle a leaked key?

The best way to handle a leaked key is to remove or deactivate the access key from the database or host to prevent any intrusion. 
-----------------------------------

