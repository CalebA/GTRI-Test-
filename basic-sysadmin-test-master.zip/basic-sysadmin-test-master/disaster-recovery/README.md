Disaster Recovery Design and Verification
=========================================
Answer the following questions immediately below each question.

Q1) Disaster Recovery and Continuous Operations
-----------------------------------------------
What is the relationship between DR and COOP? What are the driving factors
pertaining to this type of planning?

Diaster Recovery is being preparded for issues in an IT environment. COOP(Continuous Operations)is the planning that is to make sure a company can keep functioning even if a disater happens. The main factors that are involved in this planning are:

-Risk Evaluation
-Impact
-Continuous performace even during an emergency
-Protecting assets, facilities, equipment, and records
-Training Programs
-Minimizing damage and loss
-Orderly and timely recovery

Q2) Disaster Recovery Planning
------------------------------
How do DNS, layer-4 switches and layer-7 logic relate to DR situations? What
is a transparent failure?

DNS, layer-4 switches, and layer-7 logic all provide health checks to verify the availabilty of servers and applications. This will help find and fix issues in the early stages to prevent a disaster from occuring. 

Transparent failure refers the extent to which errors and recoveries of hosts and services within the system are invisible to the user and applications. For instance, if a server fails and the user is redirected to another server, the user will never know there was a failure.  

Q3) Disaster Recovery Practice
------------------------------
How does production deployment relate to DR? Describe the concerns with
reverting a production deployment.

Whenever a company has a production enviroment it is best to do all testing in a test environment first to verify different scenarios to minimize the effects of DR. This will help catch any issues that could have been detected in a test enviroment before reaching production. 

If a disater occurs and it causes the company to return back to an older build or revision, this could possily effect customers who are using the application at the same time. It is best to do production deployment in a maintainance build. 

Q4) DR Scenario
---------------
You have a production site with a partial service-capacity, replicated back-up
site. The primary and back-up sites are connected with a direct fiber backplane
for fail-over and consistency communication. Someone hits the fiber with a
backhoe. Is this an issue? If it is, how would you design the total system to
mitigate any problems?

Yes, this is an issue. Fiber uses data signals in the form light as its transport medium, so if the cable is cut it will not be able to transmit to its destination. 

Prevention methods:
-Use plastic rather than glass fiber 
-Use connectors with gold plating
-Add sensors to send messages to computers if no signal is coming from the fiber. 
